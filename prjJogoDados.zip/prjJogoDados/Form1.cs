﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjJogoDados
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int pote = 500;

        private void btnJogar_Click(object sender, EventArgs e)
        {
            int dado1;
            int dado2;

           
            dado1 = Sortear();
            Thread.Sleep(10);

            dado2 = Sortear();
            
            
            MostrarDado(dado1, pbDado1);
            MostrarDado(dado2, pbDado2);
            lbDado1.Text = dado1.ToString();
            lbDado2.Text = dado2.ToString();
            int soma = dado1 + dado2;
            int palpite = Int16.Parse(txtPalpite.Text);
            if (palpite == soma)
            {
                pote += Int16.Parse(txtValorAposta.Text);
                MostrarParabens();
            }
            else {
                pote -= Int16.Parse(txtValorAposta.Text);
                MostrarErro();
            }

            if (pote <= 0)
            {
                MessageBox.Show("Voce perdeu o jogo");
                pote = 500;
            }

            if (pote >= 1500)
            {
                MessageBox.Show("Voce quebrou a banca!");
                pote = 500;
            }

            lbValorPote.Text = pote.ToString("C2");
        }

        private void MostrarParabens()
        {
            Form frAcerto= new Form();
            frAcerto.Width = 400;
            frAcerto.Height = 400;
            frAcerto.Text = "Voce acertou!!!";
            frAcerto.StartPosition = FormStartPosition.CenterScreen;
            frAcerto.MaximizeBox = false;
            frAcerto.MinimizeBox = false;
            frAcerto.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            string caminho = Environment.CurrentDirectory +
                "\\simpsonAcerto.png";
            frAcerto.BackgroundImage = Image.FromFile(caminho);
            frAcerto.BackgroundImageLayout = ImageLayout.Stretch;
            frAcerto.ShowDialog();
        }

        private void MostrarErro()
        {
            Form frErro = new Form();
            frErro.Width = 400;
            frErro.Height = 400;
            frErro.Text = "Voce errou!!!";
            frErro.StartPosition = FormStartPosition.CenterScreen;
            frErro.MaximizeBox = false;
            frErro.MinimizeBox = false;
            frErro.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            string caminho = Environment.CurrentDirectory +
                "\\simpsonerro.png";
            frErro.BackgroundImage = Image.FromFile(caminho);
            frErro.BackgroundImageLayout = ImageLayout.Stretch;
            frErro.ShowDialog();
        }

        private void MostrarDado(int dado, PictureBox Box)
        {
            
            string caminho = Environment.CurrentDirectory +
                "\\dado" + dado.ToString() + ".png";
            Box.Image = Image.FromFile(caminho);
        }

        private int Sortear()
        {
            Random sorteio = new Random();
            return sorteio.Next(1, 7);

        }

      
    }
}
