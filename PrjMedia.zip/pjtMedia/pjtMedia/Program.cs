﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace prjMedia2ETA
{
    class MainClass
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            ConsoleKeyInfo tecla;
            do
            {
                Console.Clear();
                Console.Write("Digite o valor a:");
                a = Convert.ToDouble(Console.ReadLine());
                Console.Write("Digite o valor b:");
                b = Convert.ToDouble(Console.ReadLine());
                double media = (a + b) / 2;
                Console.WriteLine("Media = " + media);
                tecla = Console.ReadKey();
            } while (tecla.Key != ConsoleKey.Escape);

        }
    }
}