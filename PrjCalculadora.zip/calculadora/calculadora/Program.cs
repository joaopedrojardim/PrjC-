﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double soma;
            double sub;
            double div;
            double mult;
            double ope;

            Console.Write("Digite um numero: ");
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Digite outro numero: ");
            b = Convert.ToDouble(Console.ReadLine());

            soma = a + b;
            sub = a - b;
            div = a / b;
            mult = a * b;

            Console.WriteLine("Agora escolha uma operecão:");
            Console.WriteLine("soma (+) = 1");
            Console.WriteLine("subitracao (-) = 2");
            Console.WriteLine("divisao (/) = 3 ");
            Console.WriteLine("multiplicacao (x) = 4");
            Console.Write("Qual operacao voce escolheu? ");
            ope = Convert.ToDouble(Console.ReadLine());

            if (ope == 1){
                Console.WriteLine("A soma de " + a + " + " + b + " = " + soma);
            }
            else if (ope == 2){
                Console.WriteLine("A subtracao de " + a + " - " + b + " = " + sub);
            }
            else if (ope == 3){
                Console.WriteLine("A divisao de " + a + " / " + b + " = " + div);
            }
            else if (ope == 4){
                Console.WriteLine("A Multiplicacao de " + a + " x " + b + " = " + mult);
            }
            else{
                Console.WriteLine("Operacao invalida");
            }
            Console.ReadKey();
        }
    }
}