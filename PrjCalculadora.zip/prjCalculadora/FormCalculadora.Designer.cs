﻿namespace prjCalculadora
{
    partial class FormCalculadora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbVisor = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnSair = new System.Windows.Forms.ToolStripMenuItem();
            this.mnConversorTemperatura = new System.Windows.Forms.ToolStripMenuItem();
            this.bntInverterSinal = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btnPontoDecimal = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnSubtrair = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnSomar = new System.Windows.Forms.Button();
            this.btnQuadrado = new System.Windows.Forms.Button();
            this.btnRaiz = new System.Windows.Forms.Button();
            this.btnFracao = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.btnPorcentegem = new System.Windows.Forms.Button();
            this.btnCE = new System.Windows.Forms.Button();
            this.btnBackspace = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnSeno = new System.Windows.Forms.Button();
            this.btnCoseno = new System.Windows.Forms.Button();
            this.btnTangente = new System.Windows.Forms.Button();
            this.btnMetade = new System.Windows.Forms.Button();
            this.btnPI = new System.Windows.Forms.Button();
            this.btnLogaritimo = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.lbVisor);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(465, 94);
            this.panel1.TabIndex = 0;
            // 
            // lbVisor
            // 
            this.lbVisor.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbVisor.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVisor.Location = new System.Drawing.Point(10, 31);
            this.lbVisor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbVisor.Name = "lbVisor";
            this.lbVisor.Size = new System.Drawing.Size(446, 57);
            this.lbVisor.TabIndex = 0;
            this.lbVisor.Text = "0";
            this.lbVisor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnArquivo,
            this.mnConversorTemperatura});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(465, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "Arquivo";
            // 
            // mnArquivo
            // 
            this.mnArquivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnSair});
            this.mnArquivo.Name = "mnArquivo";
            this.mnArquivo.Size = new System.Drawing.Size(70, 20);
            this.mnArquivo.Text = "ARQUIVO";
            // 
            // mnSair
            // 
            this.mnSair.Name = "mnSair";
            this.mnSair.Size = new System.Drawing.Size(152, 22);
            this.mnSair.Text = "SAIR";
            this.mnSair.Click += new System.EventHandler(this.mnSair_Click);
            // 
            // mnConversorTemperatura
            // 
            this.mnConversorTemperatura.Name = "mnConversorTemperatura";
            this.mnConversorTemperatura.Size = new System.Drawing.Size(186, 20);
            this.mnConversorTemperatura.Text = "CONVERSOR DE TEMPERATURA";
            this.mnConversorTemperatura.Click += new System.EventHandler(this.mnConversorTemperatura_Click);
            // 
            // bntInverterSinal
            // 
            this.bntInverterSinal.BackColor = System.Drawing.SystemColors.Control;
            this.bntInverterSinal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bntInverterSinal.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntInverterSinal.Location = new System.Drawing.Point(8, 507);
            this.bntInverterSinal.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.bntInverterSinal.Name = "bntInverterSinal";
            this.bntInverterSinal.Size = new System.Drawing.Size(80, 73);
            this.bntInverterSinal.TabIndex = 26;
            this.bntInverterSinal.Text = "±";
            this.bntInverterSinal.UseVisualStyleBackColor = false;
            this.bntInverterSinal.Click += new System.EventHandler(this.bntInverterSinal_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn2.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.ForeColor = System.Drawing.Color.White;
            this.btn2.Location = new System.Drawing.Point(92, 426);
            this.btn2.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(80, 73);
            this.btn2.TabIndex = 22;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btnPontoDecimal
            // 
            this.btnPontoDecimal.BackColor = System.Drawing.SystemColors.Control;
            this.btnPontoDecimal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPontoDecimal.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPontoDecimal.Location = new System.Drawing.Point(176, 507);
            this.btnPontoDecimal.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnPontoDecimal.Name = "btnPontoDecimal";
            this.btnPontoDecimal.Size = new System.Drawing.Size(80, 73);
            this.btnPontoDecimal.TabIndex = 28;
            this.btnPontoDecimal.Text = ",";
            this.btnPontoDecimal.UseVisualStyleBackColor = false;
            this.btnPontoDecimal.Click += new System.EventHandler(this.btnPontoDecimal_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn4.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.ForeColor = System.Drawing.Color.White;
            this.btn4.Location = new System.Drawing.Point(92, 345);
            this.btn4.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(80, 73);
            this.btn4.TabIndex = 16;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn6.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.ForeColor = System.Drawing.Color.White;
            this.btn6.Location = new System.Drawing.Point(176, 345);
            this.btn6.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(80, 73);
            this.btn6.TabIndex = 18;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn7.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.ForeColor = System.Drawing.Color.White;
            this.btn7.Location = new System.Drawing.Point(8, 264);
            this.btn7.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(80, 73);
            this.btn7.TabIndex = 11;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn8.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.ForeColor = System.Drawing.Color.White;
            this.btn8.Location = new System.Drawing.Point(92, 264);
            this.btn8.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(80, 73);
            this.btn8.TabIndex = 12;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn9.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.ForeColor = System.Drawing.Color.White;
            this.btn9.Location = new System.Drawing.Point(176, 264);
            this.btn9.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(80, 73);
            this.btn9.TabIndex = 13;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn5.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.ForeColor = System.Drawing.Color.White;
            this.btn5.Location = new System.Drawing.Point(8, 345);
            this.btn5.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(80, 73);
            this.btn5.TabIndex = 17;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn0.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.ForeColor = System.Drawing.Color.White;
            this.btn0.Location = new System.Drawing.Point(92, 507);
            this.btn0.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(80, 73);
            this.btn0.TabIndex = 27;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn1.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.ForeColor = System.Drawing.Color.White;
            this.btn1.Location = new System.Drawing.Point(8, 426);
            this.btn1.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(80, 73);
            this.btn1.TabIndex = 21;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.MidnightBlue;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn3.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.ForeColor = System.Drawing.Color.White;
            this.btn3.Location = new System.Drawing.Point(176, 426);
            this.btn3.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(80, 73);
            this.btn3.TabIndex = 23;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.BackColor = System.Drawing.SystemColors.Control;
            this.btnMultiplicar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMultiplicar.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplicar.Location = new System.Drawing.Point(260, 264);
            this.btnMultiplicar.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(80, 73);
            this.btnMultiplicar.TabIndex = 14;
            this.btnMultiplicar.Text = "×";
            this.btnMultiplicar.UseVisualStyleBackColor = false;
            this.btnMultiplicar.Click += new System.EventHandler(this.btnMultiplicar_Click);
            // 
            // btnSubtrair
            // 
            this.btnSubtrair.BackColor = System.Drawing.SystemColors.Control;
            this.btnSubtrair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSubtrair.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubtrair.Location = new System.Drawing.Point(260, 345);
            this.btnSubtrair.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnSubtrair.Name = "btnSubtrair";
            this.btnSubtrair.Size = new System.Drawing.Size(80, 73);
            this.btnSubtrair.TabIndex = 19;
            this.btnSubtrair.Text = "-";
            this.btnSubtrair.UseVisualStyleBackColor = false;
            this.btnSubtrair.Click += new System.EventHandler(this.btnSubtrair_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnCalcular.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCalcular.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(260, 507);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(80, 73);
            this.btnCalcular.TabIndex = 29;
            this.btnCalcular.Text = "=";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnSomar
            // 
            this.btnSomar.BackColor = System.Drawing.SystemColors.Control;
            this.btnSomar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSomar.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSomar.Location = new System.Drawing.Point(260, 426);
            this.btnSomar.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(80, 73);
            this.btnSomar.TabIndex = 24;
            this.btnSomar.Text = "+";
            this.btnSomar.UseVisualStyleBackColor = false;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // btnQuadrado
            // 
            this.btnQuadrado.BackColor = System.Drawing.Color.AliceBlue;
            this.btnQuadrado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnQuadrado.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuadrado.Location = new System.Drawing.Point(92, 183);
            this.btnQuadrado.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnQuadrado.Name = "btnQuadrado";
            this.btnQuadrado.Size = new System.Drawing.Size(80, 73);
            this.btnQuadrado.TabIndex = 7;
            this.btnQuadrado.Text = "x²";
            this.btnQuadrado.UseVisualStyleBackColor = false;
            this.btnQuadrado.Click += new System.EventHandler(this.btnQuadrado_Click);
            // 
            // btnRaiz
            // 
            this.btnRaiz.BackColor = System.Drawing.Color.AliceBlue;
            this.btnRaiz.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRaiz.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRaiz.Location = new System.Drawing.Point(176, 183);
            this.btnRaiz.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnRaiz.Name = "btnRaiz";
            this.btnRaiz.Size = new System.Drawing.Size(80, 73);
            this.btnRaiz.TabIndex = 8;
            this.btnRaiz.Text = "√x";
            this.btnRaiz.UseVisualStyleBackColor = false;
            this.btnRaiz.Click += new System.EventHandler(this.btnRaiz_Click);
            // 
            // btnFracao
            // 
            this.btnFracao.BackColor = System.Drawing.Color.AliceBlue;
            this.btnFracao.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFracao.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFracao.Location = new System.Drawing.Point(8, 183);
            this.btnFracao.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnFracao.Name = "btnFracao";
            this.btnFracao.Size = new System.Drawing.Size(80, 73);
            this.btnFracao.TabIndex = 6;
            this.btnFracao.Text = "⅟🗴";
            this.btnFracao.UseVisualStyleBackColor = false;
            this.btnFracao.Click += new System.EventHandler(this.btnFracao_Click);
            // 
            // btnDividir
            // 
            this.btnDividir.BackColor = System.Drawing.SystemColors.Control;
            this.btnDividir.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDividir.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDividir.Location = new System.Drawing.Point(260, 183);
            this.btnDividir.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(80, 73);
            this.btnDividir.TabIndex = 9;
            this.btnDividir.Text = "÷";
            this.btnDividir.UseVisualStyleBackColor = false;
            this.btnDividir.Click += new System.EventHandler(this.btnDividir_Click);
            // 
            // btnPorcentegem
            // 
            this.btnPorcentegem.BackColor = System.Drawing.Color.AliceBlue;
            this.btnPorcentegem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPorcentegem.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPorcentegem.Location = new System.Drawing.Point(8, 102);
            this.btnPorcentegem.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnPorcentegem.Name = "btnPorcentegem";
            this.btnPorcentegem.Size = new System.Drawing.Size(81, 73);
            this.btnPorcentegem.TabIndex = 1;
            this.btnPorcentegem.Text = "%";
            this.btnPorcentegem.UseVisualStyleBackColor = false;
            this.btnPorcentegem.Click += new System.EventHandler(this.btnPorcentegem_Click);
            // 
            // btnCE
            // 
            this.btnCE.BackColor = System.Drawing.Color.AliceBlue;
            this.btnCE.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCE.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCE.Location = new System.Drawing.Point(92, 102);
            this.btnCE.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnCE.Name = "btnCE";
            this.btnCE.Size = new System.Drawing.Size(80, 73);
            this.btnCE.TabIndex = 2;
            this.btnCE.Text = "CE";
            this.btnCE.UseVisualStyleBackColor = false;
            this.btnCE.Click += new System.EventHandler(this.btnCE_Click);
            // 
            // btnBackspace
            // 
            this.btnBackspace.BackColor = System.Drawing.Color.AliceBlue;
            this.btnBackspace.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBackspace.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackspace.Location = new System.Drawing.Point(260, 102);
            this.btnBackspace.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnBackspace.Name = "btnBackspace";
            this.btnBackspace.Size = new System.Drawing.Size(80, 73);
            this.btnBackspace.TabIndex = 4;
            this.btnBackspace.Text = "🔙";
            this.btnBackspace.UseVisualStyleBackColor = false;
            this.btnBackspace.Click += new System.EventHandler(this.btnBackspace_Click);
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.AliceBlue;
            this.btnC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnC.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC.Location = new System.Drawing.Point(176, 102);
            this.btnC.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(80, 73);
            this.btnC.TabIndex = 3;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnSeno
            // 
            this.btnSeno.BackColor = System.Drawing.Color.AliceBlue;
            this.btnSeno.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSeno.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSeno.Location = new System.Drawing.Point(344, 264);
            this.btnSeno.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnSeno.Name = "btnSeno";
            this.btnSeno.Size = new System.Drawing.Size(111, 73);
            this.btnSeno.TabIndex = 15;
            this.btnSeno.Text = "Sen";
            this.btnSeno.UseVisualStyleBackColor = false;
            this.btnSeno.Click += new System.EventHandler(this.btnSeno_Click);
            // 
            // btnCoseno
            // 
            this.btnCoseno.BackColor = System.Drawing.Color.AliceBlue;
            this.btnCoseno.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCoseno.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoseno.Location = new System.Drawing.Point(344, 345);
            this.btnCoseno.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnCoseno.Name = "btnCoseno";
            this.btnCoseno.Size = new System.Drawing.Size(111, 73);
            this.btnCoseno.TabIndex = 20;
            this.btnCoseno.Text = "Cos";
            this.btnCoseno.UseVisualStyleBackColor = false;
            this.btnCoseno.Click += new System.EventHandler(this.btnCoseno_Click);
            // 
            // btnTangente
            // 
            this.btnTangente.BackColor = System.Drawing.Color.AliceBlue;
            this.btnTangente.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTangente.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTangente.Location = new System.Drawing.Point(344, 426);
            this.btnTangente.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnTangente.Name = "btnTangente";
            this.btnTangente.Size = new System.Drawing.Size(111, 73);
            this.btnTangente.TabIndex = 25;
            this.btnTangente.Text = "Tan";
            this.btnTangente.UseVisualStyleBackColor = false;
            this.btnTangente.Click += new System.EventHandler(this.btnTangente_Click);
            // 
            // btnMetade
            // 
            this.btnMetade.BackColor = System.Drawing.Color.AliceBlue;
            this.btnMetade.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMetade.Font = new System.Drawing.Font("Stencil", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMetade.Location = new System.Drawing.Point(344, 183);
            this.btnMetade.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnMetade.Name = "btnMetade";
            this.btnMetade.Size = new System.Drawing.Size(111, 73);
            this.btnMetade.TabIndex = 10;
            this.btnMetade.Text = "½";
            this.btnMetade.UseVisualStyleBackColor = false;
            this.btnMetade.Click += new System.EventHandler(this.btnMetade_Click);
            // 
            // btnPI
            // 
            this.btnPI.BackColor = System.Drawing.Color.AliceBlue;
            this.btnPI.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPI.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPI.Location = new System.Drawing.Point(344, 507);
            this.btnPI.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnPI.Name = "btnPI";
            this.btnPI.Size = new System.Drawing.Size(111, 73);
            this.btnPI.TabIndex = 30;
            this.btnPI.Text = "π";
            this.btnPI.UseVisualStyleBackColor = false;
            this.btnPI.Click += new System.EventHandler(this.btnPI_Click);
            // 
            // btnLogaritimo
            // 
            this.btnLogaritimo.BackColor = System.Drawing.Color.AliceBlue;
            this.btnLogaritimo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogaritimo.Font = new System.Drawing.Font("Stencil", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogaritimo.Location = new System.Drawing.Point(344, 102);
            this.btnLogaritimo.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.btnLogaritimo.Name = "btnLogaritimo";
            this.btnLogaritimo.Size = new System.Drawing.Size(111, 73);
            this.btnLogaritimo.TabIndex = 5;
            this.btnLogaritimo.Text = "Log";
            this.btnLogaritimo.UseVisualStyleBackColor = false;
            this.btnLogaritimo.Click += new System.EventHandler(this.btnLogaritimo_Click);
            // 
            // FormCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(465, 584);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btnPI);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.btnLogaritimo);
            this.Controls.Add(this.btnMetade);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.btnTangente);
            this.Controls.Add(this.btnSubtrair);
            this.Controls.Add(this.btnCoseno);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btnPorcentegem);
            this.Controls.Add(this.btnFracao);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btnPontoDecimal);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btnRaiz);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btnSeno);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnBackspace);
            this.Controls.Add(this.btnCE);
            this.Controls.Add(this.btnQuadrado);
            this.Controls.Add(this.bntInverterSinal);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FormCalculadora";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CALCULADORA";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbVisor;
        private System.Windows.Forms.Button bntInverterSinal;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btnPontoDecimal;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Button btnSubtrair;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.Button btnQuadrado;
        private System.Windows.Forms.Button btnRaiz;
        private System.Windows.Forms.Button btnFracao;
        private System.Windows.Forms.Button btnDividir;
        private System.Windows.Forms.Button btnPorcentegem;
        private System.Windows.Forms.Button btnCE;
        private System.Windows.Forms.Button btnBackspace;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnSeno;
        private System.Windows.Forms.Button btnCoseno;
        private System.Windows.Forms.Button btnTangente;
        private System.Windows.Forms.Button btnMetade;
        private System.Windows.Forms.Button btnPI;
        private System.Windows.Forms.Button btnLogaritimo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnArquivo;
        private System.Windows.Forms.ToolStripMenuItem mnSair;
        private System.Windows.Forms.ToolStripMenuItem mnConversorTemperatura;
    }
}

