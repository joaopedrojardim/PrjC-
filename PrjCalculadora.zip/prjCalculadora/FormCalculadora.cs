﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCalculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }

        Calculadora calc = new Calculadora("0","");
        bool EstadoIgual = false;

        private void btnCE_Click(object sender, EventArgs e)
        {
            calc = new Calculadora("0", "");
            lbVisor.Text = calc.Visor;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            TestarIgual(sender,e);
            calc.setDigito(btn1.Text);
            lbVisor.Text = calc.Visor;
        }

        private void TestarIgual(object sender, EventArgs e)
        {
            if (EstadoIgual)
            {
                btnCE_Click(sender, e);
                EstadoIgual = false;
            }
        }


        private void btn0_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn0.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn2.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn3.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn4.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn5.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn6.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn7.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn8.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn9.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            calc.Op = "+";
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            calc.calcular();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            calc.Op = "-";
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            calc.Op = "*";
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            calc.Op = "/";
        }

        private void bntInverterSinal_Click(object sender, EventArgs e)
        {
            calc.InverterSinal();
            lbVisor.Text = calc.Visor;
        }

        private void btnPontoDecimal_Click(object sender, EventArgs e)
        {
            calc.PontoDecimal();
            lbVisor.Text = calc.Visor;
        }

        private void btnFracao_Click(object sender, EventArgs e)
        {
            calc.Fracao();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnQuadrado_Click(object sender, EventArgs e)
        {
            calc.QuadradoNumero();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            calc.RaizQuadrada();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnPorcentegem_Click(object sender, EventArgs e)
        {
            calc.Porcentagem();
            lbVisor.Text = calc.Visor;

        }

        private void btnC_Click(object sender, EventArgs e)
        {
            calc.Visor = "0";
            lbVisor.Text = calc.Visor;
        
        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            calc.Backspace();
            lbVisor.Text = calc.Visor;
        }

        private void btnSeno_Click(object sender, EventArgs e)
        {
            calc.Seno();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnCoseno_Click(object sender, EventArgs e)
        {
            calc.Cosseno();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnTangente_Click(object sender, EventArgs e)
        {
            calc.Tangente();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnMetade_Click(object sender, EventArgs e)
        {
            calc.Metade();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnPI_Click(object sender, EventArgs e)
        {
            calc.PI();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void btnLogaritimo_Click(object sender, EventArgs e)
        {
            calc.Logaritimo();
            lbVisor.Text = calc.Visor;
            EstadoIgual = true;
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char tecla = e.KeyChar;
            if (Char.IsDigit(tecla))
            {
                TestarIgual(sender, e);
                calc.setDigito(tecla.ToString());
                lbVisor.Text = calc.Visor;
            }

            if (tecla == '+') btnSomar_Click(sender, e);
            if (tecla == '-') btnSubtrair_Click(sender, e);
            if (tecla == '*') btnMultiplicar_Click(sender, e);
            if (tecla == '/') btnDividir_Click(sender, e);

            if (tecla == '=') btnCalcular_Click(sender, e);
        }

        private void mnSair_Click(object sender, EventArgs e)
        {
            // sai do programa!
            Environment.Exit(0);
        }

        private void mnConversorTemperatura_Click(object sender, EventArgs e)
        {
            prjTermometro.FormTermometro janela = new prjTermometro.FormTermometro();
            janela.Show();
        }
    }
}
