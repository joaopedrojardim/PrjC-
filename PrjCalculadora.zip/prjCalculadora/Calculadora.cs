﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjCalculadora
{
    class Calculadora
    {
        public string Visor { get; set; }
        public double Aux1 { get; set; }
        public double Aux2 { get; set; }


        private string op;
        public string Op {
            get { return op; }
            set{
                 Aux1 = Convert.ToDouble(Visor);
                 Visor = "0";
                 Aux2 = 0;
                 op = value;
                }
            }



        public Calculadora(string Visor, string Op)
        {
            this.Visor = Visor;
            this.Op = Op;
            this.Aux1 = 0;
            this.Aux2 = 0;
        }
        public void setDigito(string digito)
        {
            if (Visor.Length > 15) return;
            if (Visor.Equals("0")) Visor = digito;
            else Visor += digito;
        }
        public void calcular()
        {
            if (Aux2 == 0) Aux2 = Convert.ToDouble(Visor);
            if (Op.Equals("+")) Aux1 += Aux2;
            if (Op.Equals("-")) Aux1 -= Aux2;
            if (Op.Equals("*")) Aux1 *= Aux2;
            if (Op.Equals("/")) Aux1 /= Aux2;

            Visor = Aux1.ToString();
        }

        public void InverterSinal()
        {
            double valor = Double.Parse(Visor);
            Visor = (valor * -1).ToString();
        }

        public void PontoDecimal()
        {
            if (!Visor.Contains(","))
            {
                Visor += ",";
            }
        }

        public void Fracao()
        {
            double valor = Double.Parse(Visor);
            Visor = (1 / valor).ToString();
        }

        public void QuadradoNumero()
        {
            double valor = Double.Parse(Visor);
            Visor = (valor * valor).ToString();
        }

        public void RaizQuadrada()
        {
            double valor = Double.Parse(Visor);
            Visor = Math.Sqrt(valor).ToString();
        }

        public void Porcentagem()
        {
            double porcentagem = Double.Parse(Visor);
            double valor = Aux1 * porcentagem / 100;
            Visor = valor.ToString();
        }

        public void Backspace()
        {
            string valor = Visor.Substring(0, Visor.Length - 1);
            if(valor.Equals("")) Visor = "0";
            else Visor = valor;
        }

        public void Seno()
        {
            double angulo = Double.Parse(Visor) / 180 * Math.PI;
            Visor = Math.Sin(angulo).ToString();
        }

        public void Cosseno()
        {
            double angulo = Double.Parse(Visor) / 180 * Math.PI;
            Visor = Math.Cos(angulo).ToString();
        }

        public void Tangente()
        {
            double angulo = Double.Parse(Visor) / 180 * Math.PI;
            Visor = Math.Tan(angulo).ToString();
        }

        public void Metade()
        {
            double valor = Double.Parse(Visor);
            Visor = (valor / 2).ToString();
        }

        public void PI()
        {
            Visor = (Math.PI).ToString("N7");
        }

        public void Logaritimo()
        {
            double valor = Double.Parse(Visor);
            Visor = Math.Log10(valor).ToString();
        }
    }
}
