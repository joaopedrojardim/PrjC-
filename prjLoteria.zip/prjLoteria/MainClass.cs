﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjLoteria
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.Black;
            ConsoleKeyInfo tecla;
            Console.Title = "Gerador de Cartelas";
            do
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Clear();
                Console.WriteLine("MENU GERADOR DE CARTELAS - MODO CONSOLE");
                Console.WriteLine("1 - MegaSena");
                Console.WriteLine("2 - Lotomania");
                Console.WriteLine("3 - LotoFacil");
                Console.WriteLine("4 - Quina");
                Console.Write("Digite opcao:");
                tecla = Console.ReadKey();
                if (tecla.Key == ConsoleKey.D1) megasena();
                if (tecla.Key == ConsoleKey.D2) Lotomania();
                if (tecla.Key == ConsoleKey.D3) LotoFacil();
                if (tecla.Key == ConsoleKey.D4) Quina();
            } while (tecla.Key != ConsoleKey.Escape);
        }

        private static void Quina()
        {
            Cartela jogo = new Cartela(80);
            Console.Clear();
            Console.CursorVisible = false;
            jogo.sortear(80, 5);
            jogo.Desenhar(10, 8);
            Console.ReadKey();
            Console.CursorVisible = true;
        }

        private static void LotoFacil()
        {
            Cartela jogo = new Cartela(25);
            Console.Clear();
            Console.CursorVisible = false;
            jogo.sortear(25, 10);
            jogo.Desenhar(5, 5);
            Console.ReadKey();
            Console.CursorVisible = true;
        }

        private static void Lotomania()
        {
            Cartela jogo = new Cartela(100);
            Console.Clear();
            Console.CursorVisible = false;
            jogo.sortear(100, 50);
            jogo.Desenhar(10, 10);
            Console.ReadKey();
            Console.CursorVisible = true;
        }
        private static void megasena()
        {
            Cartela jogo = new Cartela(60);
            Console.Clear();
            Console.CursorVisible = false;
            jogo.sortear(60, 6);
            jogo.Desenhar(6, 10);
            Console.ReadKey();
            Console.CursorVisible = true;
        }
    }
}