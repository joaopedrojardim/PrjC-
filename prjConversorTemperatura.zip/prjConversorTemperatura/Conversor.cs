﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjConversorTemperatura
{
    class Conversor
    {
        public static double ToFah(double c)
        {
            return (c * 1.8) + 32;
        }
        public static double ToKelvin(double c)
        {
            return c + 273.15;
        }
        public static double ToReamur(double c)
        {
            return c*0.8;
        }
    }
}
