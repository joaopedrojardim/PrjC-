﻿namespace prjConversorTemperatura
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtTemperatura = new System.Windows.Forms.TextBox();
            this.btnKelvin = new System.Windows.Forms.Button();
            this.btnFah = new System.Windows.Forms.Button();
            this.btnReamur = new System.Windows.Forms.Button();
            this.lbResposta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Temperatura em Celsius:";
            // 
            // txtTemperatura
            // 
            this.txtTemperatura.Location = new System.Drawing.Point(15, 29);
            this.txtTemperatura.Name = "txtTemperatura";
            this.txtTemperatura.Size = new System.Drawing.Size(183, 23);
            this.txtTemperatura.TabIndex = 1;
            this.txtTemperatura.Text = "0";
            this.txtTemperatura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnKelvin
            // 
            this.btnKelvin.ForeColor = System.Drawing.Color.Black;
            this.btnKelvin.Location = new System.Drawing.Point(15, 59);
            this.btnKelvin.Name = "btnKelvin";
            this.btnKelvin.Size = new System.Drawing.Size(183, 23);
            this.btnKelvin.TabIndex = 2;
            this.btnKelvin.Text = "Kelvin";
            this.btnKelvin.UseVisualStyleBackColor = true;
            this.btnKelvin.Click += new System.EventHandler(this.btnKelvin_Click);
            // 
            // btnFah
            // 
            this.btnFah.ForeColor = System.Drawing.Color.Black;
            this.btnFah.Location = new System.Drawing.Point(15, 88);
            this.btnFah.Name = "btnFah";
            this.btnFah.Size = new System.Drawing.Size(183, 23);
            this.btnFah.TabIndex = 2;
            this.btnFah.Text = "Fah";
            this.btnFah.UseVisualStyleBackColor = true;
            this.btnFah.Click += new System.EventHandler(this.btnFah_Click);
            // 
            // btnReamur
            // 
            this.btnReamur.ForeColor = System.Drawing.Color.Black;
            this.btnReamur.Location = new System.Drawing.Point(15, 117);
            this.btnReamur.Name = "btnReamur";
            this.btnReamur.Size = new System.Drawing.Size(183, 23);
            this.btnReamur.TabIndex = 2;
            this.btnReamur.Text = "Reamur";
            this.btnReamur.UseVisualStyleBackColor = true;
            this.btnReamur.Click += new System.EventHandler(this.btnReamur_Click);
            // 
            // lbResposta
            // 
            this.lbResposta.BackColor = System.Drawing.Color.DarkCyan;
            this.lbResposta.Location = new System.Drawing.Point(15, 147);
            this.lbResposta.Name = "lbResposta";
            this.lbResposta.Size = new System.Drawing.Size(183, 54);
            this.lbResposta.TabIndex = 3;
            this.lbResposta.Text = "RESPOSTA";
            this.lbResposta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(213, 219);
            this.Controls.Add(this.lbResposta);
            this.Controls.Add(this.btnReamur);
            this.Controls.Add(this.btnFah);
            this.Controls.Add(this.btnKelvin);
            this.Controls.Add(this.txtTemperatura);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CONVERSOR TEMPERATURA ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTemperatura;
        private System.Windows.Forms.Button btnKelvin;
        private System.Windows.Forms.Button btnFah;
        private System.Windows.Forms.Button btnReamur;
        private System.Windows.Forms.Label lbResposta;
    }
}

