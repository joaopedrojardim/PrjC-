﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjConversorTemperatura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnKelvin_Click(object sender, EventArgs e)
        {
            double c = double.Parse(txtTemperatura.Text);

            lbResposta.Text = "Kelvin = " + Conversor.ToKelvin(c); 
        }

        private void btnFah_Click(object sender, EventArgs e)
        {
            double c = double.Parse(txtTemperatura.Text);

            lbResposta.Text = "Fah = " + Conversor.ToFah(c); 
        }

        private void btnReamur_Click(object sender, EventArgs e)
        {
            double c = double.Parse(txtTemperatura.Text);

            lbResposta.Text = "Reamur = " + Conversor.ToReamur (c); 
        }
    }
}
