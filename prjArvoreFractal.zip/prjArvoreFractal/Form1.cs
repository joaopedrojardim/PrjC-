﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjArvoreFractal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Arvore arvore;

        private void btnDesenhar_Click(object sender, EventArgs e)
        {
            arvore = new Arvore(pbArvore.CreateGraphics(), pbArvore.Width, pbArvore.Height);

            Random sorteio = new Random();

            arvore.Angulo = sorteio.Next(1, 180);
            lbAngulo.Text = arvore.Angulo.ToString() + "°";
            arvore.Desenhar();
        }

        private void hsbAngulo_Scroll(object sender, ScrollEventArgs e)
        {
            if (arvore != null)
            {
                arvore.Angulo = hsbAngulo.Value; 
                lbAngulo.Text = arvore.Angulo.ToString() + "°";
                arvore.Desenhar();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
