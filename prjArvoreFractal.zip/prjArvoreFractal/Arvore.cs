﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace prjArvoreFractal
{
    class Arvore
    {
        public Graphics Tela { get; set; }

        public Pen Caneta { get; set; }

        public int Width { get; set; }

        public int Heigh { get; set; }

        public int Angulo { get; set; }

        public Arvore(Graphics Tela, int Whidth, int Heigh)
        {
            this.Tela = Tela;

            Caneta = new Pen(Color.Black, 4);

            Angulo = 30;

            this.Width = Whidth;
            this.Heigh = Heigh;
        }

        public void Desenhar()
        {
            Tela.ResetTransform();//limpa o sistema de cordenadas
            Tela.Clear(Color.Cyan);
            Tela.TranslateTransform(Width / 2, Heigh);
            Random sorteio = new Random();
            
            int R = sorteio.Next(20, 255);
            Thread.Sleep(1);
            int G = sorteio.Next(20, 255);
            Thread.Sleep(1);
            int B = sorteio.Next(20, 255);
            Thread.Sleep(1);
            Caneta.Color = Color.FromArgb(R, G, B);
            Tronco(sorteio.Next(40, Heigh / 2));
        }

        private void Tronco(double len)
        {
            //Caneta.Color = Color.Brown;
            Tela.DrawLine(Caneta,0, 0, 0, (int)-len);
            Tela.TranslateTransform(0,(float)- len,System.Drawing.Drawing2D.MatrixOrder.Prepend);
            //Thread.Sleep(10);
            if (len > 5)
            {
                GraphicsState Estado = Tela.Save();
                Tela.RotateTransform(Angulo, System.Drawing.Drawing2D.MatrixOrder.Prepend);

                Random sorteio = new Random();
                double crescimento = (double)sorteio.Next(50, 65);
                Tronco(len * crescimento/100f);

                Tela.Restore(Estado);
                Tela.RotateTransform(-Angulo, System.Drawing.Drawing2D.MatrixOrder.Prepend);
                Tronco(len * crescimento / 100f);
                Tela.Restore(Estado);
                
                
            }
            
        }


    }
}
