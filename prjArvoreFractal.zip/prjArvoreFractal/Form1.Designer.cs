﻿namespace prjArvoreFractal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbArvore = new System.Windows.Forms.PictureBox();
            this.btnDesenhar = new System.Windows.Forms.Button();
            this.lbAngulo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.hsbAngulo = new System.Windows.Forms.HScrollBar();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbArvore)).BeginInit();
            this.SuspendLayout();
            // 
            // pbArvore
            // 
            this.pbArvore.BackColor = System.Drawing.Color.White;
            this.pbArvore.Location = new System.Drawing.Point(12, 12);
            this.pbArvore.Name = "pbArvore";
            this.pbArvore.Size = new System.Drawing.Size(539, 365);
            this.pbArvore.TabIndex = 0;
            this.pbArvore.TabStop = false;
            // 
            // btnDesenhar
            // 
            this.btnDesenhar.Location = new System.Drawing.Point(12, 402);
            this.btnDesenhar.Name = "btnDesenhar";
            this.btnDesenhar.Size = new System.Drawing.Size(109, 72);
            this.btnDesenhar.TabIndex = 1;
            this.btnDesenhar.Text = "DESENHAR ARVORE";
            this.btnDesenhar.UseVisualStyleBackColor = true;
            this.btnDesenhar.Click += new System.EventHandler(this.btnDesenhar_Click);
            // 
            // lbAngulo
            // 
            this.lbAngulo.BackColor = System.Drawing.Color.Gainsboro;
            this.lbAngulo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbAngulo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbAngulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAngulo.Location = new System.Drawing.Point(291, 402);
            this.lbAngulo.Name = "lbAngulo";
            this.lbAngulo.Size = new System.Drawing.Size(174, 71);
            this.lbAngulo.TabIndex = 2;
            this.lbAngulo.Text = "0";
            this.lbAngulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(127, 403);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 70);
            this.label1.TabIndex = 3;
            this.label1.Text = "Angulo:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hsbAngulo
            // 
            this.hsbAngulo.Location = new System.Drawing.Point(12, 381);
            this.hsbAngulo.Maximum = 180;
            this.hsbAngulo.Minimum = 1;
            this.hsbAngulo.Name = "hsbAngulo";
            this.hsbAngulo.Size = new System.Drawing.Size(539, 19);
            this.hsbAngulo.TabIndex = 4;
            this.hsbAngulo.Value = 1;
            this.hsbAngulo.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsbAngulo_Scroll);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Image = global::prjArvoreFractal.Properties.Resources.Close;
            this.button1.Location = new System.Drawing.Point(477, 403);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 71);
            this.button1.TabIndex = 5;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(563, 485);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.hsbAngulo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbAngulo);
            this.Controls.Add(this.btnDesenhar);
            this.Controls.Add(this.pbArvore);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ARVORE FRACTAL";
            ((System.ComponentModel.ISupportInitialize)(this.pbArvore)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbArvore;
        private System.Windows.Forms.Button btnDesenhar;
        private System.Windows.Forms.Label lbAngulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.HScrollBar hsbAngulo;
        private System.Windows.Forms.Button button1;
    }
}

