﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjForca
{
    public partial class Form1 : Form
    {
        Forca jogo;
        string[] lista;
        string[] dicas;
        Label[] Letras; // letras a serem desenhadas no painel
        int Erros = 0;
        SoundPlayer som;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            PreencherLista();
            jogo = new Forca(lista, 0);
            jogo.Sortear(); // realiza o sorteio
            DesenharPalavra(jogo.DevolverPalavra());
            lbPalavra.Text = "DICA: " + dicas[jogo.Pos]; //exibe a dica
            timer1.Enabled = true;
            try
            {
                som = new SoundPlayer(); // cria o objeto sonoro
                som.SoundLocation = Environment.CurrentDirectory + "\\fundosom.wav";
                som.PlayLooping(); // toca em loop
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message + ":" +
                    Environment.CurrentDirectory + "\\fundosom.wav");
            }
        }
        private void PreencherLista()
        {
            string caminho = Environment.CurrentDirectory + "\\lista.txt";
            StreamReader arquivo = new StreamReader(caminho); // le o arquivo
            int qtd = File.ReadAllLines(caminho).Count();
            lista = new string[qtd];
            dicas = new string[qtd];

            
            for (int i = 0; i < qtd; i++)
            {
                string linha = arquivo.ReadLine();
                string[] partes = linha.Split(',');
                lista[i] = partes[0];
                dicas[i] = partes[1];
            }
            arquivo.Close();
        }
        private void DesenharPalavra(string p)
        {
            Letras = new Label[p.Length];
            int pv = 10;
            int ph = 10;
            for (int i = 0; i < Letras.Count(); i++)
            {
                Letras[i] = new Label();
                Letras[i].Text = "?";
                Letras[i].Width = 40;
                Letras[i].Height = 40;
                Letras[i].AutoSize = false;
                Letras[i].BorderStyle = BorderStyle.FixedSingle;
                Letras[i].TextAlign = ContentAlignment.MiddleCenter;
                Letras[i].ForeColor = Color.Red;
                Letras[i].BackColor = Color.Transparent;
                if (i % 10 == 0 && i != 0)
                {
                    pv += 42;
                    ph = 10;
                }
                Letras[i].Top = pv;
                Letras[i].Left = ph;
                ph += 42;
                Letras[i].Show();
                pnPalavra.Controls.Add(Letras[i]);
            }
        }
        private void btnJogar_Click(object sender, EventArgs e)
        {
            DesenharLetra(txtLetra.Text);
            txtLetra.Focus();
            txtLetra.SelectAll();
        }
        private void DesenharLetra(string letra)
        {
            string p = jogo.DevolverPalavra(); // p = "roma"
            bool achou = false;
            if (lblLetrasDigitadas.Text.Contains(letra))
            {
                MessageBox.Show("Letra já digitada");
                return; // finaliza o método
            }
            lblLetrasDigitadas.Text += letra;
            for (int i = 0; i < Letras.Count(); i++)
            {
                if (p.Substring(i, 1).Equals(letra))
                {
                    Letras[i].Text = letra;
                    achou = true;
                }
            }
            if (achou == false)
            {
                Erros++;
                DesenharBoneco();
            }
            if (Erros == 6)
            {
                timer1.Enabled = false;
                MessageBox.Show("Voce perdeu!. A palavra era: " + p);
                NovoJogo();
            }
            TestarVitoria();
        }
        private void TestarVitoria()
        {
            string tmp = "";
            for (int i = 0; i < Letras.Count(); i++)
            {
                tmp += Letras[i].Text;
            }
            if (tmp.Equals(jogo.DevolverPalavra()))
            {
                timer1.Enabled = false;
                MessageBox.Show("Voce ganhou o jogo!!!!");
                NovoJogo();
            }
        }
        private void NovoJogo()
        {
            jogo.Sortear();
            pnPalavra.Controls.Clear();
            DesenharPalavra(jogo.DevolverPalavra());
            lbPalavra.Text = "DICA: " + dicas[jogo.Pos]; //exibe a dica
            Erros = 0;
            pbBoneco.Image = null;
            lblLetrasDigitadas.Text = "";
            timer1.Enabled = true; //ativar o cronometro
            lbCronometro.Text = "120";
        }
        private void DesenharBoneco()
        {
            try
            {
                string pasta = Environment.CurrentDirectory + "\\imagens\\";
                string arquivo = pasta + "forca" + Erros.ToString() + ".png";
                pbBoneco.Image = Image.FromFile(arquivo);
            }
            catch (Exception)
            {
                MessageBox.Show("imagem não encontrada");
            }

        }
        private void btnNovoJogo_Click(object sender, EventArgs e)
        {
            NovoJogo();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            int seg = Convert.ToInt16(lbCronometro.Text);
            seg--;
            lbCronometro.Text = seg.ToString();
            if (seg == 0)
            {
                timer1.Enabled = false;
                MessageBox.Show("Voce perdeu o jogo. A palavra era " +
                    jogo.DevolverPalavra());
                NovoJogo();
            }
        }
    }
}
