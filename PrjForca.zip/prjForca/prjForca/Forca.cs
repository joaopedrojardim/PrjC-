﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjForca
{
    public class Forca
    {
        private string[] Palavras;
        public int Pos { get; set; } 

        public Forca (string[] Palavras, int Pos)
        {
            this.Palavras = Palavras;
            this.Pos = Pos;
        }

        public void Sortear ()
        {
            Random sorteio = new Random();
            this.Pos = sorteio.Next(0,Palavras.Count());
        }

        public string DevolverPalavra()
        {
            return Palavras[this.Pos];
        }
    }
}
