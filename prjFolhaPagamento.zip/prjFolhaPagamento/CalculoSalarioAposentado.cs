﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjFolhaPagamento
{
    class CalculoSalarioAposentado : ICalcularSalario
    {
        public int Cod { get; set; }
        public string Nome { get; set; }

         public CalculoSalarioAposentado(int Cod, string Nome)
        {
            this.Cod = Cod;
            this.Nome = Nome;
        }
        public CalculoSalarioAposentado() 
            : this(0, "")
        {

        }

        public double CalcularSalarioBruto(double SalarioHora)
        {
            //clacula o salario bruto
            double sb = 200 * SalarioHora;
            if (sb > 5050) sb = 5050;
            return sb;
        }

        public void Imprimir()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("----------------------------");
            Console.WriteLine("CALCULO SALARIO APOSENTADO");
            Console.WriteLine("----------------------------");
            Console.WriteLine("COD:{0}\tNOME:{1}", Cod, Nome.ToUpper());
        }
    }
}
