﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjFolhaPagamento
{
    class CalculoSalarioEstagiario : ICalcularSalario
    {
        public int Cod { get; set; }
        public string Nome { get; set; }
        public double HorasTrabalhadas { get; set; }
        public double Auxilio { get; set; }

        public CalculoSalarioEstagiario(int Cod, string Nome, double HorasTrabalhadas,
          double Auxilio)
        {
            this.Cod = Cod;
            this.Nome = Nome;
            this.HorasTrabalhadas = HorasTrabalhadas;
            this.Auxilio = Auxilio;
        }
        public CalculoSalarioEstagiario()
            : this(0, "", 100f, 40f)
        {

        }

        public double CalcularSalarioBruto(double SalarioHora)
        {
            if (HorasTrabalhadas > 90) HorasTrabalhadas = 90;
            double sb = SalarioHora * HorasTrabalhadas;
            if (sb < 525) sb = 525;
            return sb + Auxilio;
        }

        public void Imprimir()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("----------------------------");
            Console.WriteLine("CALCULO SALARIO ESTAGIARIO");
            Console.WriteLine("----------------------------");
            Console.WriteLine("COD:{0}\tNOME:{1}", Cod, Nome.ToUpper());
            Console.WriteLine("HORAS TRABALHADAS: {0} HORAS MES", HorasTrabalhadas);
            Console.WriteLine("AUXILIO : {0}", Auxilio);
        }
    }
}
