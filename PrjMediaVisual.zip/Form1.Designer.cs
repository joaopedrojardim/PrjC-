﻿namespace pjtMedia
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.btnMedia = new System.Windows.Forms.Button();
            this.lblResposta = new System.Windows.Forms.Label();
            this.btnGeometrica = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lstHistorico = new System.Windows.Forms.ListBox();
            this.btnLimparHistorico = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "DIGITE O NUMERO A:";
            // 
            // txtA
            // 
            this.txtA.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtA.ForeColor = System.Drawing.Color.Red;
            this.txtA.Location = new System.Drawing.Point(12, 40);
            this.txtA.MaxLength = 20;
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(248, 29);
            this.txtA.TabIndex = 1;
            this.txtA.Text = "0";
            this.txtA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtA_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "DIGITE O NUMERO B:";
            // 
            // txtB
            // 
            this.txtB.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB.ForeColor = System.Drawing.Color.Red;
            this.txtB.Location = new System.Drawing.Point(12, 99);
            this.txtB.MaxLength = 20;
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(248, 29);
            this.txtB.TabIndex = 2;
            this.txtB.Text = "0";
            this.txtB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtB_KeyDown);
            this.txtB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtB_KeyPress);
            // 
            // btnMedia
            // 
            this.btnMedia.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnMedia.FlatAppearance.BorderSize = 3;
            this.btnMedia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnMedia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnMedia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedia.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.btnMedia.Location = new System.Drawing.Point(12, 153);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(248, 35);
            this.btnMedia.TabIndex = 3;
            this.btnMedia.Text = " CALCULAR MEDIA ARITIMETICA";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // lblResposta
            // 
            this.lblResposta.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lblResposta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResposta.Location = new System.Drawing.Point(12, 258);
            this.lblResposta.Name = "lblResposta";
            this.lblResposta.Size = new System.Drawing.Size(248, 31);
            this.lblResposta.TabIndex = 4;
            this.lblResposta.Text = "RESPOSTA";
            this.lblResposta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGeometrica
            // 
            this.btnGeometrica.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnGeometrica.FlatAppearance.BorderSize = 3;
            this.btnGeometrica.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnGeometrica.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnGeometrica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGeometrica.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.btnGeometrica.Location = new System.Drawing.Point(12, 205);
            this.btnGeometrica.Name = "btnGeometrica";
            this.btnGeometrica.Size = new System.Drawing.Size(248, 35);
            this.btnGeometrica.TabIndex = 3;
            this.btnGeometrica.Text = "CALCULAR MÉDIA GEOMETRICA";
            this.btnGeometrica.UseVisualStyleBackColor = true;
            this.btnGeometrica.Click += new System.EventHandler(this.btnGeometrica_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(392, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(195, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "HISTÓRICO DOS CALCULOS";
            // 
            // lstHistorico
            // 
            this.lstHistorico.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstHistorico.ForeColor = System.Drawing.Color.Red;
            this.lstHistorico.FormattingEnabled = true;
            this.lstHistorico.ItemHeight = 21;
            this.lstHistorico.Location = new System.Drawing.Point(334, 40);
            this.lstHistorico.Name = "lstHistorico";
            this.lstHistorico.Size = new System.Drawing.Size(337, 172);
            this.lstHistorico.TabIndex = 6;
            // 
            // btnLimparHistorico
            // 
            this.btnLimparHistorico.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnLimparHistorico.FlatAppearance.BorderSize = 3;
            this.btnLimparHistorico.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnLimparHistorico.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnLimparHistorico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimparHistorico.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.btnLimparHistorico.Location = new System.Drawing.Point(376, 234);
            this.btnLimparHistorico.Name = "btnLimparHistorico";
            this.btnLimparHistorico.Size = new System.Drawing.Size(248, 35);
            this.btnLimparHistorico.TabIndex = 3;
            this.btnLimparHistorico.Text = " LIMPAR HISTÓRICO";
            this.btnLimparHistorico.UseVisualStyleBackColor = true;
            this.btnLimparHistorico.Click += new System.EventHandler(this.btnLimparHistorico_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(720, 307);
            this.Controls.Add(this.lstHistorico);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblResposta);
            this.Controls.Add(this.btnGeometrica);
            this.Controls.Add(this.btnLimparHistorico);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.LawnGreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PROGRAMA DA MÉDIA";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Label lblResposta;
        private System.Windows.Forms.Button btnGeometrica;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lstHistorico;
        private System.Windows.Forms.Button btnLimparHistorico;
    }
}

