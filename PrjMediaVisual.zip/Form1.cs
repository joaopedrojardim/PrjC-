﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pjtMedia
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            try
            {

            double a = Convert.ToDouble(txtA.Text);
            double b = Convert.ToDouble(txtB.Text);
            double m = (a + b) / 2;

            lblResposta.Text = "Média aritimetica = " + m.ToString("N5");

            if (testar(m))
            {
                lstHistorico.Items.Add("Média Num de " + a.ToString() + " e " + b.ToString() + " = " + m.ToString());
            }   

            }
            catch (Exception err)
            {

                MessageBox.Show("Um erro aconteceu: " + err.Message);
                lblResposta.Text = "Resposta";

            }
           
        }

        private bool testar(double m)
        {
            foreach (string item in lstHistorico.Items)
            {
                if (item.Contains(m.ToString())){
                    return false;
                }
                
            }
            return true;
        }

        
         
        
        private void txtA_KeyPress(object sender, KeyPressEventArgs e)
        {

            validarTecla(sender, e,txtA.Text);
            
        }

        private void txtB_KeyPress(object sender, KeyPressEventArgs e)
        {

            validarTecla(sender, e,txtB.Text);
       
        }


            private void validarTecla(object sender, KeyPressEventArgs e,string texto){
            
            char tecla = e.KeyChar;

            if (char.IsLetter(tecla)) // texta se é letra 
            {
                e.Handled = true; // cancela o pressionameto da tecla   
            }

            if (tecla == '.')
            {
                tecla = ',';
                e.KeyChar = ',';
            }
            if (texto.Contains(",") && e.KeyChar == ',') // txta contem virgola
            {
                e.Handled = true; // cancela virgula extra  
            }

            if (txtA.Text.Contains(",") && e.KeyChar == ',') // txta contem virgola
            {
                e.Handled = true; // cancela virgula extra  
            }

            if (char.IsPunctuation(tecla) && tecla != ',')
            {
                e.Handled = true;
            }

        }

            private void txtB_KeyDown(object sender, KeyEventArgs e)
            {
                if (e.KeyCode== Keys.Enter)
                {
                    btnMedia_Click(sender, e); // excuta o botao media  
                }
            }

            private void btnGeometrica_Click(object sender, EventArgs e)
            {
                try
                {

                    double a = Convert.ToDouble(txtA.Text);
                    double b = Convert.ToDouble(txtB.Text);
                    double m = Math.Sqrt(a * b);

                    lblResposta.Text = "Média Geometrica = " + m.ToString("N5");

                    if (testar(m))
                    {
                        lstHistorico.Items.Add("Média Geo de " + a.ToString() + " e " + b.ToString() + " = " + m.ToString());
                    }
                    }
                    
                catch (Exception err)
                {

                    MessageBox.Show("Um erro aconteceu: " + err.Message);
                    lblResposta.Text = "Resposta";

                }
            }

            private void btnLimparHistorico_Click(object sender, EventArgs e)
            {
                lstHistorico.Items.Clear();
            }
    }
}
