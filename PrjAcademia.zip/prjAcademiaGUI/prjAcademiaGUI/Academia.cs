﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace prjAcademiaGUI
{
    class Academia
    {
        public BindingList<Aluno> Alunos { get; set; }
        public Academia(BindingList<Aluno> Alunos)
        {
            this.Alunos = Alunos;
        }
        public void matricular(Aluno novo)
        {
            AlunoDB tabela = new AlunoDB();
            tabela.inserir(novo);
            Alunos.Add(novo);
        }
        public Aluno Pesquisar(int Cod)
        {
            return Alunos.FirstOrDefault(reg => reg.Id == Cod);
        }
        public void Excluir(Aluno reg)
        {
            Alunos.Remove(reg);
            AlunoDB tabela = new AlunoDB();
            tabela.excluir(reg);

        }

        public void editar(Aluno Registro)
        {
            Aluno velho = Alunos.FirstOrDefault(i => i.Id == Registro.Id);
            velho.Nome = Registro.Nome;
            velho.Idade = Registro.Idade;
            velho.Peso = Registro.Peso;
            velho.Altura = Registro.Altura;
            AlunoDB tabela = new AlunoDB();
            tabela.editar(Registro);
        }
    }
}