﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.IO;

namespace prjAcademiaGUI
{
    class ServidorSQL
    {
        public SQLiteConnection Conexao { get; set; }
        public SQLiteConnection Open()
        {
            string caminho = Environment.CurrentDirectory + "\\academia.sqlite";
            string sql = String.Format("Data Source = {0}; version = 3", caminho);
            Conexao = new SQLiteConnection(sql);
            Conexao.Open();
            return Conexao;
        }
        public bool criarBanco()
        {
            string caminho = Environment.CurrentDirectory + "\\academia.sqlite";
            if (!File.Exists(caminho))
            {
                SQLiteConnection.CreateFile(caminho);
                criarTabelas();
                return true;
            }
            return false;
        }

        private void criarTabelas()
        {
            try
            {
                using (var banco = new SQLiteCommand(Open()))
                {
                    banco.CommandText = "CREATE TABLE ALUNO (ID INT PRIMARY KEY, NOME VARCHAR(45), IDADE INT, PESO DOUBLE, ALTURA DOUBLE)";
                    banco.ExecuteNonQuery();
                }
            }
            catch (Exception Erro)
            {
                System.Windows.Forms.MessageBox.Show("Erro ao criar tabela:" + Erro.Message);
            }
            
        }
    }
}
