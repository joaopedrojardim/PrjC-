﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjAcademiaGUI
{
    public partial class FormFichaMatricola : Form
    {
        internal Academia BoaForma { get; set; }
        internal Aluno Registro { get; set; }

        public FormFichaMatricola()
        {
            InitializeComponent();
        }



        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (Validacoes() == false) return;

            if (Registro == null) novo();
            else editar();
            this.Dispose();
        }


        private bool Validacoes()
        {
            if (txtNome.Text == string.Empty)
            {
                ep.SetError(txtNome, "Nome não pode ser vazio");
                ep.SetIconPadding(txtNome, 2);
                return false;
            }
            else ep.SetError(txtNome, "");


            if (txtIdade.Text == string.Empty)
            {
                ep.SetError(txtIdade, "Idade não pode ser vazio");
                ep.SetIconPadding(txtIdade, 2);
                return false;
            }
            else ep.SetError(txtIdade, "");

            int idade = Convert.ToInt16(txtIdade.Text);
            if (idade < 15)
            {
                ep.SetError(txtIdade, "A idade deve ser maior que 15 anos");
                ep.SetIconPadding(txtIdade, 2);
                return false;
            }
            else ep.SetError(txtIdade, "");



            if (txtPeso.Text == string.Empty)
            {
                ep.SetError(txtPeso, "Peso não pode ser vazio");
                ep.SetIconPadding(txtPeso, 2);
                return false;
            }
            else ep.SetError(txtPeso, "");

            int peso = Convert.ToInt16(txtPeso.Text);
            if (peso < 40 || peso > 300)
            {
                ep.SetError(txtPeso, "O peso deve ser maior que 40 kg e menor que 300 kg");
                ep.SetIconPadding(txtPeso, 2);
                return false;
            }
            else ep.SetError(txtPeso, "");




            if (txtAltura.Text == string.Empty)
            {
                ep.SetError(txtAltura, "Altura não pode ser vazio");
                ep.SetIconPadding(txtAltura, 2);
                return false;
            }
            else ep.SetError(txtAltura, "");

            double altura = Convert.ToDouble(txtAltura.Text);
            if (altura < 0.50 || altura > 2.40)
            {
                ep.SetError(txtAltura, "A altura deve ser maior que 0,50 m e menor que 2,40 m");
                ep.SetIconPadding(txtAltura, 2);
                return false;
            }
            else ep.SetError(txtAltura, "");

            return true;
        }


        private void novo()
        {
            AlunoDB tabela = new AlunoDB();
            Registro = new Aluno()
            {
                Id = tabela.ProximoCodigo(),
                Nome = txtNome.Text,
                Idade = Int16.Parse(txtIdade.Text),
                Peso = Double.Parse(txtPeso.Text),
                Altura = Double.Parse(txtAltura.Text)
            };
            BoaForma.matricular(Registro);
            MessageBox.Show("Matricula Efetuada!", "Sucesso", MessageBoxButtons.OK,
                MessageBoxIcon.Exclamation);
        }

        private void editar()
        {
            Registro.Nome = txtNome.Text;
            Registro.Idade = Int16.Parse(txtIdade.Text);
            Registro.Peso = Double.Parse(txtPeso.Text);
            Registro.Altura = Double.Parse(txtAltura.Text);
            BoaForma.editar(Registro);
            MessageBox.Show("Matricula Editada!", "Sucesso", MessageBoxButtons.OK,
                MessageBoxIcon.Exclamation);
        }

        private void FormFichaMatricola_Load(object sender, EventArgs e)
        {
            if (Registro != null)
            {
                txtNome.Text = Registro.Nome;
                txtIdade.Text = Registro.Idade.ToString();
                txtPeso.Text = Registro.Peso.ToString();
                txtAltura.Text = Registro.Altura.ToString();
            }
            txtNome.Focus();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Registro = null;
            this.Dispose();
        }

    }
}
