﻿namespace prjCalculadoraGeometrica
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.gbCalculos = new System.Windows.Forms.GroupBox();
            this.rbVolume = new System.Windows.Forms.RadioButton();
            this.rbArea = new System.Windows.Forms.RadioButton();
            this.rbPerimetro = new System.Windows.Forms.RadioButton();
            this.gbCirculo = new System.Windows.Forms.GroupBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtRaio = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbResposta = new System.Windows.Forms.GroupBox();
            this.lblResposta = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnDesenho = new System.Windows.Forms.Panel();
            this.chkDesenharCirculo = new System.Windows.Forms.CheckBox();
            this.btnCorDesenho = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.btnCorBalde = new System.Windows.Forms.Button();
            this.gbCalculos.SuspendLayout();
            this.gbCirculo.SuspendLayout();
            this.gbResposta.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbCalculos
            // 
            this.gbCalculos.Controls.Add(this.rbVolume);
            this.gbCalculos.Controls.Add(this.rbArea);
            this.gbCalculos.Controls.Add(this.rbPerimetro);
            this.gbCalculos.Location = new System.Drawing.Point(12, 12);
            this.gbCalculos.Name = "gbCalculos";
            this.gbCalculos.Size = new System.Drawing.Size(156, 134);
            this.gbCalculos.TabIndex = 0;
            this.gbCalculos.TabStop = false;
            // 
            // rbVolume
            // 
            this.rbVolume.AutoSize = true;
            this.rbVolume.Location = new System.Drawing.Point(17, 86);
            this.rbVolume.Name = "rbVolume";
            this.rbVolume.Size = new System.Drawing.Size(74, 19);
            this.rbVolume.TabIndex = 2;
            this.rbVolume.Text = "VOLUME";
            this.rbVolume.UseVisualStyleBackColor = true;
            // 
            // rbArea
            // 
            this.rbArea.AutoSize = true;
            this.rbArea.Location = new System.Drawing.Point(17, 56);
            this.rbArea.Name = "rbArea";
            this.rbArea.Size = new System.Drawing.Size(55, 19);
            this.rbArea.TabIndex = 1;
            this.rbArea.Text = "ÁREA";
            this.rbArea.UseVisualStyleBackColor = true;
            // 
            // rbPerimetro
            // 
            this.rbPerimetro.AutoSize = true;
            this.rbPerimetro.Checked = true;
            this.rbPerimetro.Location = new System.Drawing.Point(17, 26);
            this.rbPerimetro.Name = "rbPerimetro";
            this.rbPerimetro.Size = new System.Drawing.Size(91, 19);
            this.rbPerimetro.TabIndex = 0;
            this.rbPerimetro.TabStop = true;
            this.rbPerimetro.Text = "PERIMETRO";
            this.rbPerimetro.UseVisualStyleBackColor = true;
            // 
            // gbCirculo
            // 
            this.gbCirculo.Controls.Add(this.btnCalcular);
            this.gbCirculo.Controls.Add(this.txtRaio);
            this.gbCirculo.Controls.Add(this.label1);
            this.gbCirculo.Location = new System.Drawing.Point(175, 12);
            this.gbCirculo.Name = "gbCirculo";
            this.gbCirculo.Size = new System.Drawing.Size(168, 134);
            this.gbCirculo.TabIndex = 1;
            this.gbCirculo.TabStop = false;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(7, 94);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(155, 27);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Tag = "";
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtRaio
            // 
            this.txtRaio.Location = new System.Drawing.Point(7, 57);
            this.txtRaio.MaxLength = 10;
            this.txtRaio.Name = "txtRaio";
            this.txtRaio.Size = new System.Drawing.Size(155, 23);
            this.txtRaio.TabIndex = 1;
            this.txtRaio.Text = "0";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(3, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "DIGITE O RAIO:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // gbResposta
            // 
            this.gbResposta.Controls.Add(this.lblResposta);
            this.gbResposta.Controls.Add(this.label2);
            this.gbResposta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbResposta.Location = new System.Drawing.Point(350, 12);
            this.gbResposta.Name = "gbResposta";
            this.gbResposta.Size = new System.Drawing.Size(200, 134);
            this.gbResposta.TabIndex = 2;
            this.gbResposta.TabStop = false;
            // 
            // lblResposta
            // 
            this.lblResposta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResposta.Location = new System.Drawing.Point(22, 66);
            this.lblResposta.Name = "lblResposta";
            this.lblResposta.Size = new System.Drawing.Size(161, 55);
            this.lblResposta.TabIndex = 2;
            this.lblResposta.Text = "0,000";
            this.lblResposta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(3, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "RESPOSTA";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pnDesenho
            // 
            this.pnDesenho.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnDesenho.Location = new System.Drawing.Point(12, 172);
            this.pnDesenho.Name = "pnDesenho";
            this.pnDesenho.Size = new System.Drawing.Size(535, 316);
            this.pnDesenho.TabIndex = 3;
            // 
            // chkDesenharCirculo
            // 
            this.chkDesenharCirculo.AutoSize = true;
            this.chkDesenharCirculo.Checked = true;
            this.chkDesenharCirculo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDesenharCirculo.Location = new System.Drawing.Point(12, 510);
            this.chkDesenharCirculo.Name = "chkDesenharCirculo";
            this.chkDesenharCirculo.Size = new System.Drawing.Size(141, 19);
            this.chkDesenharCirculo.TabIndex = 5;
            this.chkDesenharCirculo.Text = "DESENHAR CIRCULO";
            this.chkDesenharCirculo.UseVisualStyleBackColor = true;
            // 
            // btnCorDesenho
            // 
            this.btnCorDesenho.Location = new System.Drawing.Point(159, 506);
            this.btnCorDesenho.Name = "btnCorDesenho";
            this.btnCorDesenho.Size = new System.Drawing.Size(166, 23);
            this.btnCorDesenho.TabIndex = 6;
            this.btnCorDesenho.Text = "MUDAR COR DA BORDA";
            this.btnCorDesenho.UseVisualStyleBackColor = true;
            this.btnCorDesenho.Click += new System.EventHandler(this.btnCorDesenho_Click);
            // 
            // btnCorBalde
            // 
            this.btnCorBalde.Location = new System.Drawing.Point(350, 506);
            this.btnCorBalde.Name = "btnCorBalde";
            this.btnCorBalde.Size = new System.Drawing.Size(183, 23);
            this.btnCorBalde.TabIndex = 7;
            this.btnCorBalde.Text = "MUDAR COR DE DENTRO";
            this.btnCorBalde.UseVisualStyleBackColor = true;
            this.btnCorBalde.Click += new System.EventHandler(this.btnCorBalde_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(575, 554);
            this.Controls.Add(this.btnCorBalde);
            this.Controls.Add(this.btnCorDesenho);
            this.Controls.Add(this.chkDesenharCirculo);
            this.Controls.Add(this.pnDesenho);
            this.Controls.Add(this.gbResposta);
            this.Controls.Add(this.gbCirculo);
            this.Controls.Add(this.gbCalculos);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CALCULADORA GEOMÉTRICA";
            this.gbCalculos.ResumeLayout(false);
            this.gbCalculos.PerformLayout();
            this.gbCirculo.ResumeLayout(false);
            this.gbCirculo.PerformLayout();
            this.gbResposta.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbCalculos;
        private System.Windows.Forms.RadioButton rbVolume;
        private System.Windows.Forms.RadioButton rbArea;
        private System.Windows.Forms.RadioButton rbPerimetro;
        private System.Windows.Forms.GroupBox gbCirculo;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtRaio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbResposta;
        private System.Windows.Forms.Label lblResposta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnDesenho;
        private System.Windows.Forms.CheckBox chkDesenharCirculo;
        private System.Windows.Forms.Button btnCorDesenho;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button btnCorBalde;
    }
}

