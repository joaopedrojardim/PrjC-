﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCalculadoraGeometrica
{
    public partial class Form1 : Form
    {
        Color cor = Color.Black;
        Color cor2 = Color.Black;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double raio = Convert.ToDouble(txtRaio.Text);
            if (rbPerimetro.Checked == true)
            {
                double p = 2 * Math.PI * raio;
                lblResposta.Text = "Perimetro\n" + p.ToString("N3") +" cm";
            }
            if (rbArea.Checked == true)
            {
                double a = Math.PI * Math.Pow(raio, 2);
                lblResposta.Text = "Área\n" + a.ToString("N3") + " cm";
            }
            if (rbVolume.Checked == true)
            {
                double v = 3f / 4f  * Math.PI * Math.Pow(raio, 3);
                lblResposta.Text = "Volume\n" + v.ToString("N3") + " cm";
            }

            if (chkDesenharCirculo.Checked) Desenhar();
            else pnDesenho.CreateGraphics().Clear(Color.WhiteSmoke);

        }


        private void Desenhar()
        {
            Graphics tela = pnDesenho.CreateGraphics();
            tela.Clear(Color.WhiteSmoke);
            Pen caneta = new Pen(Color.Black, 4);
            SolidBrush balde = new SolidBrush(cor2);

            int cy = pnDesenho.Height / 2;
            int cx = pnDesenho.Width / 2;
            int r = Convert.ToInt16(txtRaio.Text);

            tela.DrawLine(caneta, 0, cy, pnDesenho.Width, cy);
            tela.DrawLine(caneta, cx, 0, cx, pnDesenho.Height);
            caneta.Color = cor;
            tela.DrawEllipse(caneta, cx - r, cy - r, r * 2, r * 2);
            tela.FillEllipse(balde, cx - r, cy - r, r * 2, r * 2);
        }

        private void btnCorDesenho_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            cor = colorDialog1.Color;
        }

        private void btnCorBalde_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            cor2 = colorDialog1.Color;
        }



       

 
    }
}
