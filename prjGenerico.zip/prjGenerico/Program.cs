﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjGenerico
{
    class Program
    {
        static Imprimir<Aluno> ListaAlunos;
        static Imprimir<Professor> ListaProfessor;
        static Imprimir<Funcionario> ListaFuncionario;
        static void Main(string[] args)
        {
            string escolha = "1";
            do{
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Clear();

            
                Console.WriteLine("Oque deseja ver ?");
                Console.WriteLine("0 - Sair");
                Console.WriteLine("1 - Alunos");
                Console.WriteLine("2 - Professor");
                Console.WriteLine("3 - Funcionario");
                escolha = Console.ReadLine();
            
            
                ListaAlunos = new Imprimir<Aluno>(new List<Aluno>(){
                        new Aluno(1,"João", "INF","3J"),
                        new Aluno(2,"Maria", "ENF","2A"),
                        new Aluno(3,"Jose", "ENF","2A"),
                        new Aluno(4,"Ana", "MIN","2C"),
                        new Aluno(5,"Joaquim", "QUI","2M")
                });

                ListaProfessor = new Imprimir<Professor>(new List<Professor>(){
                    new Professor (1,"Aquiles", "DS"),
                    new Professor (2,"Ana Paula", "BD"),
                    new Professor (3,"Danilo", "PW"),
                    new Professor (4,"Cadu", "ECO"),
                    new Professor (5,"Jeremias", "FTS"),
                });

                ListaFuncionario = new Imprimir<Funcionario>(new List<Funcionario>()
                {
                      new Funcionario(1,"Mateus", 12, 3),
                      new Funcionario(2,"Ricardo", 15,9),
                      new Funcionario(3,"Matias", 12, 34),
                      new Funcionario(4,"Daniella", 234,3),
                      new Funcionario(5,"Marianaa", 45, 123)
                });

                if (escolha == "1")
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    ListaAlunos.Exibir();
                    Console.ReadKey();
                    Console.Clear();

                }else if(escolha == "2"){
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    ListaProfessor.Exibir();
                    Console.ReadKey();
                    Console.Clear();
                }
                else if (escolha == "3") {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    ListaFuncionario.Exibir();
                    Console.ReadKey();
                    Console.Clear();
                }else{
                    Environment.Exit(0);
                }

                Console.Clear();
            }while(escolha != "0");
        }
    }
}
