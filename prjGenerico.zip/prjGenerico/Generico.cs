﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjGenerico
{
    class Generico <T>
    {
        public T Valor { get; set; }

        public Generico(T Valor)
        {
            this.Valor = Valor;

        }

        public void Imprimir()
        {
            Console.WriteLine("{0} = {1}", Valor.GetType(), Valor.ToString());
        }
    }
}
