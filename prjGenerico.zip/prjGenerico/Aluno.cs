﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjGenerico
{
    class Aluno
    {
        public int RM { get; set; }
        public string Nome { get; set; }
        public string Curso { get; set; }
        public string Modulo { get; set; }

        public Aluno(int RM, string Nome, string Curso, string Modulo)
        {
            this.RM = RM;
            this.Nome = Nome;
            this.Curso = Curso;
            this.Modulo = Modulo;
        }
    }
}
