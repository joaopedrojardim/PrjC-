﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace prjGenerico
{
    class Imprimir <T>
    {
        public List<T> Lista { get; set; }

        public Imprimir(List<T> Lista)
        {
            this.Lista = Lista;
        }

        public void Exibir()
        {
            foreach (T item in Lista)
            {
                Type classe = typeof(T);
                PropertyInfo[] propiedades = classe.GetProperties();
                foreach (var campo in propiedades)
                {
                    Console.WriteLine("{0} = {1}", campo.Name, campo.GetValue(item, null), ToString());
                }
            }
        }

    }
}
