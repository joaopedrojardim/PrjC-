﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjGenerico
{
    class Funcionario
    {
        public int Matricola { get; set; }
        public string Nome { get; set; }
        public double Salario { get; set; }
        public int Idade { get; set; }

        public Funcionario(int Matricola, string Nome, double Salario, int Idade)
        {
            this.Matricola = Matricola;
            this.Nome = Nome;
            this.Salario = Salario;
            this.Idade = Idade;
        }
    }
}
