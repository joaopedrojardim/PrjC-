﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjGenerico
{
    class Professor
    {
        public int Cod { get; set; }
        public string Nome { get; set; }
        public string Disciplina { get; set; }

        public Professor(int Cod, string Nome, string Disciplina)
        {
            this.Cod = Cod;
            this.Nome = Nome;
            this.Disciplina = Disciplina;
        }
    }
}
