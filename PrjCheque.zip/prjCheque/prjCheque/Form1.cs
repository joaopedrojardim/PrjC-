﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExtensoDLL;

namespace prjCheque
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEmitir_Click(object sender, EventArgs e)
        {
            string[] partes = txtValor.Text.Split(',');
            string real = Extenso.Imprimir(Int16.Parse(partes[0]));
            string centavo = Extenso.Imprimir(Int16.Parse(partes[1]));
            string txt;

            Graphics tela = pbCheque.CreateGraphics();
            SolidBrush cor = new SolidBrush(Color.Blue);

            txt = gbBancos.Controls.OfType<RadioButton>().SingleOrDefault(RadioButton => RadioButton.Checked).Text;

            tela.DrawImage(Image.FromFile(Environment.CurrentDirectory + "\\cheque.jpg"), 0, 0);

            tela.DrawString(real + " reais e " + centavo + " centavos", new Font("Times New Roman", 14), cor, 10, 93); //Comic Sans MS

            tela.DrawString(txt, new Font("Times New Roman", 9), cor, 52, 192);

            tela.DrawString(txtNome.Text, new Font("Times New Romanc", 12), cor, 25, 125);

            tela.DrawString(txtValor.Text, new Font("Times New Roman", 17), cor, 460, 17);

            tela.DrawString(txtEndereco.Text, new Font("Times New Roman", 17), cor, 210, 193);

            string mes = dtEmissao.Value.ToString("MMMM");
            tela.DrawString(mes, new Font("Times New Roman", 15), cor, 382, 158);

            string ano = dtEmissao.Value.ToString("yyyy");
            tela.DrawString(ano, new Font("Times New Roman", 15), cor, 500, 158);

            int dia = dtEmissao.Value.Day;
            tela.DrawString(Extenso.Imprimir(dia), new Font("Times New Roman", 15), cor, 210, 158);


        }

        private void txtValor_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnEmitir_Click(sender, e);
            }
        }


    }
}
