﻿namespace prjCheque
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dtEmissao = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnEmitir = new System.Windows.Forms.Button();
            this.pbCheque = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.rbSantander = new System.Windows.Forms.RadioButton();
            this.rbBancoDoBrasil = new System.Windows.Forms.RadioButton();
            this.rbSicoobi = new System.Windows.Forms.RadioButton();
            this.rbItau = new System.Windows.Forms.RadioButton();
            this.rbBradesco = new System.Windows.Forms.RadioButton();
            this.rbCaixa = new System.Windows.Forms.RadioButton();
            this.gbBancos = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCheque)).BeginInit();
            this.gbBancos.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "VALOR DO CHEQUE ";
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(15, 30);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(353, 26);
            this.txtValor.TabIndex = 0;
            this.txtValor.Text = "0,0";
            this.txtValor.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtValor_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "DATA DE EMISSÃO ";
            // 
            // dtEmissao
            // 
            this.dtEmissao.Location = new System.Drawing.Point(12, 96);
            this.dtEmissao.Name = "dtEmissao";
            this.dtEmissao.Size = new System.Drawing.Size(356, 26);
            this.dtEmissao.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "PORTADOR";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(12, 160);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(356, 26);
            this.txtNome.TabIndex = 3;
            // 
            // btnEmitir
            // 
            this.btnEmitir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmitir.Location = new System.Drawing.Point(397, 290);
            this.btnEmitir.Name = "btnEmitir";
            this.btnEmitir.Size = new System.Drawing.Size(571, 75);
            this.btnEmitir.TabIndex = 4;
            this.btnEmitir.Text = "PREENCHER CHEQUE";
            this.btnEmitir.UseVisualStyleBackColor = true;
            this.btnEmitir.Click += new System.EventHandler(this.btnEmitir_Click);
            // 
            // pbCheque
            // 
            this.pbCheque.BackColor = System.Drawing.SystemColors.Control;
            this.pbCheque.Image = global::prjCheque.Properties.Resources.cheque;
            this.pbCheque.Location = new System.Drawing.Point(397, 21);
            this.pbCheque.Name = "pbCheque";
            this.pbCheque.Size = new System.Drawing.Size(571, 254);
            this.pbCheque.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCheque.TabIndex = 7;
            this.pbCheque.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "ENDEREÇO";
            // 
            // txtEndereco
            // 
            this.txtEndereco.Location = new System.Drawing.Point(12, 224);
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(356, 26);
            this.txtEndereco.TabIndex = 3;
            // 
            // rbSantander
            // 
            this.rbSantander.AutoSize = true;
            this.rbSantander.Checked = true;
            this.rbSantander.Location = new System.Drawing.Point(6, 15);
            this.rbSantander.Name = "rbSantander";
            this.rbSantander.Size = new System.Drawing.Size(129, 22);
            this.rbSantander.TabIndex = 8;
            this.rbSantander.TabStop = true;
            this.rbSantander.Text = "SANTANDER";
            this.rbSantander.UseVisualStyleBackColor = true;
            // 
            // rbBancoDoBrasil
            // 
            this.rbBancoDoBrasil.Location = new System.Drawing.Point(156, 15);
            this.rbBancoDoBrasil.Name = "rbBancoDoBrasil";
            this.rbBancoDoBrasil.Size = new System.Drawing.Size(191, 22);
            this.rbBancoDoBrasil.TabIndex = 8;
            this.rbBancoDoBrasil.Text = "BANCO DO BRASIL";
            this.rbBancoDoBrasil.UseVisualStyleBackColor = true;
            // 
            // rbSicoobi
            // 
            this.rbSicoobi.AutoSize = true;
            this.rbSicoobi.Location = new System.Drawing.Point(156, 71);
            this.rbSicoobi.Name = "rbSicoobi";
            this.rbSicoobi.Size = new System.Drawing.Size(93, 22);
            this.rbSicoobi.TabIndex = 8;
            this.rbSicoobi.Text = "SICOOB";
            this.rbSicoobi.UseVisualStyleBackColor = true;
            // 
            // rbItau
            // 
            this.rbItau.AutoSize = true;
            this.rbItau.Location = new System.Drawing.Point(6, 43);
            this.rbItau.Name = "rbItau";
            this.rbItau.Size = new System.Drawing.Size(68, 22);
            this.rbItau.TabIndex = 8;
            this.rbItau.Text = "ITAÚ";
            this.rbItau.UseVisualStyleBackColor = true;
            // 
            // rbBradesco
            // 
            this.rbBradesco.AutoSize = true;
            this.rbBradesco.Location = new System.Drawing.Point(156, 43);
            this.rbBradesco.Name = "rbBradesco";
            this.rbBradesco.Size = new System.Drawing.Size(118, 22);
            this.rbBradesco.TabIndex = 8;
            this.rbBradesco.Text = "BRADESCO";
            this.rbBradesco.UseVisualStyleBackColor = true;
            // 
            // rbCaixa
            // 
            this.rbCaixa.AutoSize = true;
            this.rbCaixa.Location = new System.Drawing.Point(6, 71);
            this.rbCaixa.Name = "rbCaixa";
            this.rbCaixa.Size = new System.Drawing.Size(80, 22);
            this.rbCaixa.TabIndex = 8;
            this.rbCaixa.Text = "CAIXA";
            this.rbCaixa.UseVisualStyleBackColor = true;
            // 
            // gbBancos
            // 
            this.gbBancos.Controls.Add(this.rbSantander);
            this.gbBancos.Controls.Add(this.rbSicoobi);
            this.gbBancos.Controls.Add(this.rbCaixa);
            this.gbBancos.Controls.Add(this.rbBradesco);
            this.gbBancos.Controls.Add(this.rbBancoDoBrasil);
            this.gbBancos.Controls.Add(this.rbItau);
            this.gbBancos.ForeColor = System.Drawing.Color.Transparent;
            this.gbBancos.Location = new System.Drawing.Point(15, 265);
            this.gbBancos.Name = "gbBancos";
            this.gbBancos.Size = new System.Drawing.Size(353, 100);
            this.gbBancos.TabIndex = 9;
            this.gbBancos.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(992, 379);
            this.Controls.Add(this.gbBancos);
            this.Controls.Add(this.pbCheque);
            this.Controls.Add(this.btnEmitir);
            this.Controls.Add(this.txtEndereco);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtEmissao);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtValor);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EMISSOR DE CHEQUES";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCheque)).EndInit();
            this.gbBancos.ResumeLayout(false);
            this.gbBancos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtEmissao;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnEmitir;
        private System.Windows.Forms.PictureBox pbCheque;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.RadioButton rbSantander;
        private System.Windows.Forms.RadioButton rbBancoDoBrasil;
        private System.Windows.Forms.RadioButton rbSicoobi;
        private System.Windows.Forms.RadioButton rbItau;
        private System.Windows.Forms.RadioButton rbBradesco;
        private System.Windows.Forms.RadioButton rbCaixa;
        private System.Windows.Forms.GroupBox gbBancos;
    }
}

